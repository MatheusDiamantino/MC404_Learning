//
//  treat_MMP.h
//  Assembler - IAS
//
//  Created by Matheus Diamantino on 9/22/15.
//  Copyright © 2015 Matheus Diamantino. All rights reserved.
//

#ifndef treat_MMP_h
#define treat_MMP_h

#include <stdio.h>
#include "defines.h"

void _change_position (short int new);
void _increment(bool is_word);

#endif /* treat_MMP_h */
